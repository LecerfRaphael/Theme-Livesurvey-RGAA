﻿/* =========================================================
  PACK LIME SURVEY COMPLET / NETTOYÉ (version fichier externe)
   - Gestion dates (jour/mois/année + input caché)
   - Placeholders Jour/Mois/Année
   - Nettoyage des required sur hidden/othertext/etc.
   - Transformation div → fieldset (list-dropdown, yes-no, etc.)
   - Règles REQUIRED conditionnelles (visible + mandatory)
   - Validation progressive (1ère question en erreur)
   - Gestion "Autre" (radio, checkbox, multiple-opt)
   - list-with-comment & multiple-opt-comments
   - Accessibilité : aria-live, modal, questionhelp
   - Thème LimeSurvey basé sur Fruity, adapté pour améliorer l’accessibilité numérique et la conformité au RGAA 4.
   - En amélioration continue par la Direction du numérique
   – Service DAWAM de l’Université de Lille.
   - Contact : raphael.lecerf@univ-lille.fr
   - update : 06-02-2026
   - Licence : CC BY-NC-SA
========================================================= */

(function (window, document, $) {
  "use strict";

  // ✅ Anti double-binding global (PJAX peut recharger / ré-exécuter certains scripts)
  if (window.__LS_ACCESSIBILITE_JS_LOADED__) return;
  window.__LS_ACCESSIBILITE_JS_LOADED__ = true;

  /* =========================================================
     Helpers
  ========================================================= */
  function ensureHiddenCSS() {
    if (!document.getElementById("lsHiddenStyle")) {
      var st = document.createElement("style");
      st.id = "lsHiddenStyle";
      st.textContent = ".ls-hidden{display:none!important}";
      document.head.appendChild(st);
    }
  }

  // Option B (si tu ne mets pas le div en twig) : on le crée automatiquement
  function ensureAriaLiveDiv() {
    if (document.getElementById("aria-live-message")) return;
    var div = document.createElement("div");
    div.id = "aria-live-message";
    div.setAttribute("aria-live", "polite");
    div.setAttribute("aria-atomic", "true");
    div.style.position = "absolute";
    div.style.left = "-9999px";
    document.body.appendChild(div);
  }

  function isVisible(el) {
    return !!(el && el.offsetParent !== null);
  }

  /* =========================================================
     0) Limite caractères sur input text/number (delegation jQuery)
  ========================================================= */
  function wireMaxLenDelegation() {
    if (!$) return;

    // Délégation : fonctionne aussi avec le rechargement PJAX de LimeSurvey
    $(document).on("input", 'input[type="text"], input[type="number"]', function () {
      var $field = $(this);

      var sizeAttr = parseInt($field.attr("size"), 10);
      var maxAttr = parseInt($field.attr("maxlength"), 10);

      var max = sizeAttr || maxAttr;
      if (!max || isNaN(max)) return;

      var val = $field.val().toString();

      if (val.length > max) {
        alert("Vous ne pouvez pas saisir plus de " + max + " caractères dans ce champ.");
        $field.val(val.slice(0, max));
      }
    });
  }

  /* =========================================================
     0b) relevance:on/off (JS + jQuery) : réactiver/désactiver
  ========================================================= */
  function wireRelevanceHandlers() {
    if (!$) return;

    $(document).on("relevance:on", function (event) {
      var $target = $(event.target);

      $target.removeClass("ls-hidden ls-irrelevant");
      $target.removeAttr("hidden");
      $target.css("display", "");
      $target.css("pointer-events", "auto");

      $target.find("input, select, textarea, button").each(function () {
        var $el = $(this);

        // 🔴 EXCEPTION : commentaires des multiple-opt-comments (gérés par le bloc 8a)
        if (
          $el.is('input[type="text"][id$="comment"], textarea[id$="comment"]') &&
          $el
            .closest(
              "fieldset.row.multiple-opt-comments.mandatory.question-container," +
                "fieldset.row.multiple-opt-comments.mandatory.questionnaire-container," +
                "fieldset.row.multiple-opt-comments.mandatory.question-containe"
            )
            .length
        ) {
          return;
        }

        $el.prop("disabled", false);
        $el.removeAttr("disabled");
        $el.attr("aria-disabled", "false");
      });
    });

    $(document).on("relevance:off", function (event) {
      var $target = $(event.target);

      $target.addClass("ls-hidden ls-irrelevant");
      $target.css("pointer-events", "none");

      $target.find("input, select, textarea, button").each(function () {
        $(this).prop("disabled", true);

        if ($(this).is(":checkbox") || $(this).is(":radio")) {
          $(this).prop("checked", false);
        }
        if ($(this).is(":text") || $(this).is("textarea")) {
          $(this).val("");
        }
      });
    });
  }

  /* =========================================================
     1) DATES : trio Jour/Mois/Année + input type="date" caché
  ========================================================= */
  function initDateTriplets(root) {
    (root || document).querySelectorAll(".question-container").forEach(function (q) {
      var hiddenDate = q.querySelector(".ls-js-hidden input[type='date'][id^='answer']");
      var day = q.querySelector("select.day");
      var month = q.querySelector("select.month");
      var year = q.querySelector("select.year");
      var form = q.closest("form");

      if (!hiddenDate || !day || !month || !year || !form) return;

      hiddenDate.removeAttribute("required");
      hiddenDate.setAttribute("tabindex", "-1");
      hiddenDate.setAttribute("aria-hidden", "true");
      hiddenDate.disabled = true;

      function updateHidden() {
        var dd = day.value,
          mm = month.value,
          yyyy = year.value;
        hiddenDate.value = dd && mm && yyyy ? yyyy + "-" + mm + "-" + dd : "";
      }

      [day, month, year].forEach(function (el) {
        el.addEventListener("change", updateHidden);
      });

      form.addEventListener("submit", function () {
        updateHidden();
        if (hiddenDate.value) hiddenDate.disabled = false;
      });

      q.addEventListener(
        "invalid",
        function (e) {
          if (e.target === hiddenDate) {
            e.preventDefault();
            var firstEmpty = [day, month, year].find(function (el) {
              return !el.value;
            }) || day;
            firstEmpty.focus();
          }
        },
        true
      );
    });
  }

  /* =========================================================
     1b) Placeholders Jour/Mois/Année
  ========================================================= */
  function initDatePlaceholders() {
    if (!$) return;
    $("select.day option:first").text("Jour");
    $("select.month option:first").text("Mois");
    $("select.year option:first").text("Année");
  }

  /* =========================================================
     2) Nettoyage required hidden/other/multiple + questionhelp role
  ========================================================= */
  function removeRequiredFromHiddenInputs(scope) {
    (scope || document)
      .querySelectorAll("input[type='hidden'][disabled]")
      .forEach(function (input) {
        if (input.hasAttribute("required")) input.removeAttribute("required");
      });
  }

  function removeRequiredFromOtherTextInputs(scope) {
    (scope || document)
      .querySelectorAll(".ls-js-hidden .col-12 input.form-control.input-sm")
      .forEach(function (input) {
        if ((input.id || "").indexOf("othertext") !== -1 && input.hasAttribute("required")) {
          input.removeAttribute("required");
        }
      });
  }

  function removeRequiredFromMultipleOptMandatoryFieldsets(scope) {
    (scope || document)
      .querySelectorAll("fieldset.multiple-opt.mandatory input")
      .forEach(function (input) {
        if (input.hasAttribute("required")) input.removeAttribute("required");
      });
  }

  function removeAlertRoleOnQuestionHelp(scope) {
    var root = scope || document;
    root.querySelectorAll(".ls-questionhelp[role='alert']").forEach(function (el) {
      el.removeAttribute("role");
      if (el.getAttribute("aria-live") === "assertive") {
        el.setAttribute("aria-live", "polite");
      }
    });
  }

  function initRequiredCleanupObservers() {
    removeRequiredFromHiddenInputs(document);
    removeRequiredFromOtherTextInputs(document);
    removeRequiredFromMultipleOptMandatoryFieldsets(document);
    removeAlertRoleOnQuestionHelp(document);

    var observer = new MutationObserver(function () {
      removeRequiredFromHiddenInputs(document);
      removeRequiredFromOtherTextInputs(document);
      removeRequiredFromMultipleOptMandatoryFieldsets(document);
      removeAlertRoleOnQuestionHelp(document);
    });

    observer.observe(document.body, { childList: true, subtree: true });

    document.addEventListener("pjax:success", function () {
      removeAlertRoleOnQuestionHelp(document);
    });
  }

  /* =========================================================
     3) Transformation DIV -> FIELDSET (list-dropdown, yes-no, etc.)
  ========================================================= */
  function divToFieldset(selector, withLegendSelector, root) {
    (root || document).querySelectorAll(selector).forEach(function (div) {
      if (div.tagName.toLowerCase() === "fieldset") return;
      var fs = document.createElement("fieldset");
      Array.prototype.forEach.call(div.attributes, function (attr) {
        fs.setAttribute(attr.name, attr.value);
      });
      while (div.firstChild) fs.appendChild(div.firstChild);
      div.parentNode.replaceChild(fs, div);

      if (withLegendSelector) {
        var label = fs.querySelector(withLegendSelector);
        if (label) {
          var lg = document.createElement("legend");
          lg.innerHTML = label.innerHTML;
          lg.className = label.className;
          label.parentNode.replaceChild(lg, label);
        }
      }
    });
  }

  function initDivToFieldset(root) {
    root = root || document;

    divToFieldset("div.list-dropdown", "label.ls-label-question", root);
    divToFieldset("div.yes-no", "label.ls-label-question", root);
    divToFieldset("div.numeric-multi", "label.ls-label-question", root);
    divToFieldset("div.question-container.date", "label.ls-label-question", root);
    divToFieldset("div.multiple-opt", ":scope > label", root);
    divToFieldset("div.question-container.multiple-short-txt", "label.ls-label-question", root);

    // Suppression des messages "question-valid-container"
    root.querySelectorAll("div.question-valid-container.text-info.col-12").forEach(function (div) {
      if (div.parentNode) div.parentNode.removeChild(div);
    });
  }

  /* =========================================================
     4) REQUIRED conditionnel (visible + mandatory)
  ========================================================= */
  function isHidden(el) {
    if (!el) return true;
    var cs = getComputedStyle(el);
    return cs.display === "none" || cs.visibility === "hidden" || el.classList.contains("ls-hidden");
  }

  function updateRequiredForInputsSelectsAndRadios(root) {
    (root || document).querySelectorAll(".mandatory").forEach(function (scope) {
      var hidden = isHidden(scope);
      var inputs = scope.querySelectorAll(
        'input[type="text"], input[type="email"], select:not(.day):not(.month):not(.year)'
      );
      var radios = scope.querySelectorAll('input[type="radio"]');
      var checkboxes = scope.querySelectorAll('input[type="checkbox"]');

      if (hidden) {
        inputs.forEach(function (input) {
          input.removeAttribute("required");
        });
        radios.forEach(function (radio) {
          radio.removeAttribute("required");
        });
        checkboxes.forEach(function (cb) {
          cb.removeAttribute("required");
        });
        return;
      }

      inputs.forEach(function (input) {
        var isOtherTextItem = !!input.closest(".other-text-item");
        if (isOtherTextItem) {
          input.removeAttribute("required");
          return;
        }
        if (!isHidden(input)) input.setAttribute("required", "required");
        else input.removeAttribute("required");
      });

      // radios par groupe
      var radioGroups = {};
      radios.forEach(function (radio) {
        if (!radio.name) return;
        if (!radioGroups[radio.name]) radioGroups[radio.name] = [];
        radioGroups[radio.name].push(radio);
      });

      Object.keys(radioGroups).forEach(function (name) {
        var group = radioGroups[name];
        var isSelected = group.some(function (r) {
          return r.checked;
        });
        group.forEach(function (r) {
          if (isSelected || isHidden(r)) r.removeAttribute("required");
          else r.setAttribute("required", "required");
        });
      });
    });
  }

  function validateRadioRequirementsInTable(root) {
    (root || document).querySelectorAll(".ls-table-wrapper").forEach(function (wrapper) {
      wrapper.querySelectorAll("tr").forEach(function (row) {
        var isMandatoryRow = row.classList.contains("mandatory");
        var radios = row.querySelectorAll(".radio-list input[type='radio']");
        var isSelected = Array.prototype.some.call(radios, function (r) {
          return r.checked;
        });

        radios.forEach(function (radio) {
          if (!isMandatoryRow || isHidden(radio)) {
            radio.removeAttribute("required");
          } else {
            if (isSelected) radio.removeAttribute("required");
            else radio.setAttribute("required", "required");
          }
        });
      });
    });
  }

  function initRequiredObserver() {
    updateRequiredForInputsSelectsAndRadios(document);
    validateRadioRequirementsInTable(document);

    var observer = new MutationObserver(function (mutations) {
      var need = false;
      mutations.forEach(function (m) {
        if (m.type === "attributes" || m.type === "childList") need = true;
      });
      if (need) {
        updateRequiredForInputsSelectsAndRadios(document);
        validateRadioRequirementsInTable(document);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style"]
    });
  }

  /* =========================================================
     4c) REQUIRED sur text-long/text-short mandatory (visible)
  ========================================================= */
  function addRequiredToTextLongMandatory(root) {
    (root || document).querySelectorAll(".text-long.mandatory").forEach(function (div) {
      div.querySelectorAll("input, select, textarea").forEach(function (input) {
        if (isVisible(input)) input.setAttribute("required", "required");
        else input.removeAttribute("required");
      });
    });
  }

  function updateRequiredForTextShortQuestions(root) {
    (root || document).querySelectorAll("div.text-short.mandatory").forEach(function (questionDiv) {
      var input = questionDiv.querySelector("input");
      if (!input) return;
      var previousSibling = questionDiv.previousElementSibling;
      var isHiddenDiv = questionDiv.classList.contains("ls-hidden");
      var isHiddenPrev = previousSibling && previousSibling.classList.contains("ls-hidden");
      if (isHiddenDiv || isHiddenPrev) input.removeAttribute("required");
      else if (!isHiddenDiv) input.setAttribute("required", "required");
    });
  }

  function initTextLongShortRequiredObserver() {
    addRequiredToTextLongMandatory(document);
    updateRequiredForTextShortQuestions(document);

    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        if (m.attributeName === "class" || m.type === "childList") {
          addRequiredToTextLongMandatory(document);
          updateRequiredForTextShortQuestions(document);
        }
      });
    });

    document.querySelectorAll("div.text-short.mandatory").forEach(function (div) {
      observer.observe(div, { attributes: true, attributeFilter: ["class"] });
    });
  }

  /* =========================================================
     4d) FIELDSET list-radio mandatory : required seulement si visible
  ========================================================= */
  function applyRequiredRadiosFieldsets(root) {
    (root || document)
      .querySelectorAll("fieldset.question-container.list-radio.mandatory, fieldset.list-radio.mandatory")
      .forEach(function (fieldset) {
        var visible =
          !fieldset.classList.contains("ls-hidden") &&
          !fieldset.classList.contains("ls-irrelevant") &&
          window.getComputedStyle(fieldset).display !== "none";
        var radios = fieldset.querySelectorAll('input[type="radio"][name]');
        if (!radios.length) return;

        var groups = {};
        radios.forEach(function (r) {
          if (!r.name) return;
          if (!groups[r.name]) groups[r.name] = [];
          groups[r.name].push(r);
        });

        Object.keys(groups).forEach(function (name) {
          var arr = groups[name];
          var anyChecked = arr.some(function (r) {
            return r.checked;
          });
          arr.forEach(function (r) {
            r.removeAttribute("required");
          });
          if (visible && !anyChecked) {
            var rep = arr.find(function (r) {
              return !r.disabled;
            }) || arr[0];
            if (rep) rep.setAttribute("required", "required");
          }
        });
      });
  }

  function initListRadioRequiredObserver() {
    applyRequiredRadiosFieldsets(document);

    var observer = new MutationObserver(function () {
      applyRequiredRadiosFieldsets(document);
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style"]
    });

    setTimeout(function () {
      applyRequiredRadiosFieldsets(document);
    }, 300);
    setTimeout(function () {
      applyRequiredRadiosFieldsets(document);
    }, 1000);
    setTimeout(function () {
      applyRequiredRadiosFieldsets(document);
    }, 2000);
  }

  /* =========================================================
     4f) Unhide si relevant (sauf masquage manuel)
  ========================================================= */
  function unhideIfRelevant(q) {
    if (!q) return;
    if (!q.id || !/^question/.test(q.id)) return;

    // 🔴 si cachée volontairement par JS, on ne touche pas
    if (q.dataset.lsManualHide === "1") return;

    // Si encore ls-irrelevant (EM) → on ne touche pas
    if (q.classList.contains("ls-irrelevant")) return;

    var wasHiddenClass = q.classList.contains("ls-hidden");
    var wasHiddenAttr = q.hasAttribute("hidden");
    var wasHiddenStyle = q.style.display === "none";

    if (wasHiddenClass || wasHiddenAttr || wasHiddenStyle) {
      q.classList.remove("ls-hidden");
      q.removeAttribute("hidden");
      if (q.style.display === "none") q.style.display = "";
      q.setAttribute("aria-hidden", "false");
    }
  }

  function initUnhideRelevantWatcher() {
    document.querySelectorAll('fieldset[id^="question"], div[id^="question"]').forEach(unhideIfRelevant);

    var mo = new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        if (m.type !== "attributes" || m.attributeName !== "class") return;
        var el = m.target;
        if (!el.id || !/^question/.test(el.id)) return;
        unhideIfRelevant(el);
      });
    });

    mo.observe(document.body, {
      subtree: true,
      attributes: true,
      attributeFilter: ["class"]
    });
  }

  /* =========================================================
     4g) "Si oui..." (show/hide manuel)
  ========================================================= */
  function initSiOuiQuestions(root) {
    root = root || document;

    root.querySelectorAll("fieldset.question-container legend").forEach(function (lg) {
      var txt = (lg.textContent || "").trim().toLowerCase();
      if (txt.indexOf("si oui") !== 0) return;

      var childQ = lg.closest("fieldset.question-container");
      if (!childQ || childQ.dataset.siOuiWired === "1") return;
      childQ.dataset.siOuiWired = "1";

      var prev = childQ.previousElementSibling;
      while (prev && !prev.matches("fieldset.question-container, div.question-container")) {
        prev = prev.previousElementSibling;
      }
      if (!prev) return;

      wireParentChildSiOui(prev, childQ);
    });
  }

  function wireParentChildSiOui(parentQ, childQ) {
    function setChildVisible(show) {
      if (show) {
        childQ.dataset.lsManualHide = "0";
        childQ.classList.remove("ls-hidden", "ls-irrelevant");
        childQ.removeAttribute("hidden");
        if (childQ.style.display === "none") childQ.style.display = "";
        childQ.setAttribute("aria-hidden", "false");
      } else {
        childQ.dataset.lsManualHide = "1";

        childQ.classList.add("ls-hidden");
        childQ.setAttribute("aria-hidden", "true");
        childQ.setAttribute("hidden", "hidden");
        childQ.style.display = "none";

        childQ.querySelectorAll("input, select, textarea").forEach(function (el) {
          if (el.type === "radio" || el.type === "checkbox") el.checked = false;
          else if (el.tagName === "SELECT") el.selectedIndex = 0;
          else el.value = "";

          el.required = false;
          el.removeAttribute("required");
        });
      }
    }

    var radios = parentQ.querySelectorAll("input[type='radio'][name]");
    if (!radios.length) return;

    function computeVisibility() {
      var show = false;
      radios.forEach(function (r) {
        if (!r.checked) return;
        var lab = parentQ.querySelector('label[for="' + r.id.replace(/"/g, "") + '"]');
        var txt = lab ? (lab.textContent || "").toLowerCase() : "";
        if (txt.indexOf("oui") !== -1) show = true;
      });
      setChildVisible(show);
    }

    radios.forEach(function (r) {
      if (r.dataset.siOuiBound === "1") return;
      r.dataset.siOuiBound = "1";
      r.addEventListener("change", computeVisibility);
      r.addEventListener("click", computeVisibility);
    });

    computeVisibility();
  }

  /* =========================================================
     4e) REQUIRED sur .row.text-short / .row.text-long (visible + mandatory)
  ========================================================= */
  function updateRequiredAttributes(root) {
    (root || document)
      .querySelectorAll(".row.text-short input[type='text'], .row.text-long textarea")
      .forEach(function (el) {
        var row = el.closest(".row.text-short, .row.text-long");
        if (!row) return;
        if (isVisible(row) && row.classList.contains("mandatory")) el.setAttribute("required", "required");
        else el.removeAttribute("required");
      });
  }

  function updateRadioRequiredAttributes(root) {
    (root || document).querySelectorAll(".radio-list input[type='radio']").forEach(function (radio) {
      var container = radio.closest(".radio-list");
      if (container && container.classList.contains("mandatory")) radio.setAttribute("required", "required");
      else radio.removeAttribute("required");
    });
  }

  function initRowRequiredObservers() {
    updateRequiredAttributes(document);
    updateRadioRequiredAttributes(document);

    var observer = new MutationObserver(function () {
      updateRequiredAttributes(document);
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style"]
    });

    var observer2 = new MutationObserver(function () {
      updateRadioRequiredAttributes(document);
    });
    observer2.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class"]
    });
  }

  /* =========================================================
     5) Cacher pickers calendrier GUI natifs
  ========================================================= */
  function hideNativePickers(root) {
    (root || document).querySelectorAll(".input-group-addon").forEach(function (div) {
      var calendarIcon = div.querySelector("i.fa-calendar");
      if (calendarIcon) div.style.display = "none";
    });
    (root || document).querySelectorAll(".tempus-dominus-widget").forEach(function (div) {
      div.style.display = "none";
    });
    (root || document).querySelectorAll(".date-container").forEach(function (div) {
      div.style.display = "none";
    });
  }

  /* =========================================================
     6) Auto type email/tel/num/date selon classes
  ========================================================= */
  function initAutoTypes() {
    if (window.__AUTO_TYPE_EMAIL_TEL_NUM_DATE__) return;
    window.__AUTO_TYPE_EMAIL_TEL_NUM_DATE__ = true;

    function setType(el, type) {
      try {
        var isOtherField = !!el.closest(".other-text-item");
        var hasSpecificClass = !!el.closest(".email, .tel, .num, .date, .numeric");
        if (isOtherField || !hasSpecificClass) return;
        if (el.type !== type) el.type = type;
      } catch (e) {
        if (type === "email") el.setAttribute("pattern", "[^\\s@]+@[^\\s@]+\\.[^\\s@]+");
        if (type === "tel") el.setAttribute("pattern", "[0-9+()\\s.-]{6,}");
        if (type === "number") el.setAttribute("inputmode", "numeric");
        el.setAttribute("data-fallback-type", type);
      }
    }

    function convertIn(root, cls, targetType) {
      var nodes = new Set(Array.prototype.slice.call(root.querySelectorAll("div." + cls + ", fieldset." + cls)));
      nodes.forEach(function (container) {
        if (cls === "date" && container.querySelector("select.day, select.month, select.year")) return;
        container.querySelectorAll('input[type="text"]').forEach(function (inp) {
          if (inp.disabled) return;
          if (inp.matches('[type="hidden"], [data-no-convert]')) return;

          var isOtherField = !!inp.closest(".other-text-item");
          var isInMultiple = !!inp.closest(".multiple-opt");
          var hasIdOther = (inp.id || "").indexOf("other") !== -1;
          if (isOtherField || isInMultiple || hasIdOther) return;

          setType(inp, targetType);

          if (targetType === "email") {
            if (!inp.getAttribute("autocomplete")) inp.setAttribute("autocomplete", "email");
            if (!inp.getAttribute("inputmode")) inp.setAttribute("inputmode", "email");
            if (!inp.placeholder && !inp.value) inp.placeholder = "prenom.nom@organisme.fr";
          }
          if (targetType === "tel") {
            if (!inp.getAttribute("autocomplete")) inp.setAttribute("autocomplete", "tel");
            if (!inp.getAttribute("inputmode")) inp.setAttribute("inputmode", "tel");
            if (!inp.placeholder && !inp.value) inp.placeholder = "0123456789";
          }
          if (targetType === "number") {
            if (!inp.hasAttribute("step")) inp.setAttribute("step", "1");
            if (!inp.getAttribute("inputmode")) inp.setAttribute("inputmode", "numeric");
          }
          if (targetType === "date") {
            if (!inp.placeholder && !inp.value) inp.placeholder = "aaaa-mm-jj";
          }
        });
      });
    }

    function run(root) {
      root = root || document;
      convertIn(root, "email", "email");
      convertIn(root, "tel", "tel");
      convertIn(root, "num", "number");
      convertIn(root, "date", "date");
      convertIn(root, "numeric", "number");
    }

    document.addEventListener("DOMContentLoaded", function () {
      run(document);
    });
    document.addEventListener("pjax:success", function () {
      run(document);
    });

    var mo = new MutationObserver(function (muts) {
      if (muts.some(function (m) { return m.addedNodes && m.addedNodes.length; })) {
        clearTimeout(run._t);
        run._t = setTimeout(run, 60);
      }
    });

    mo.observe(document.body, { childList: true, subtree: true });
  }

  /* =========================================================
     7.1 — Radios avec valeur "-oth-" (autre)
  ========================================================= */
  function initOtherRadios(root) {
    ensureHiddenCSS();
    root = root || document;

    function getOtherBox(scope) {
      return scope.querySelector(".text-item.other-text-item");
    }

    function setHidden(box, hide) {
      if (!box) return;
      box.classList.toggle("ls-hidden", !!hide);
      box.setAttribute("aria-hidden", hide ? "true" : "false");
      box.querySelectorAll("input[type='text'], textarea").forEach(function (inp) {
        inp.disabled = !!hide;
        if (hide) {
          inp.required = false;
          inp.removeAttribute("required");
        }
      });
    }

    function updateGroup(scope) {
      var box = getOtherBox(scope);
      if (!box) return;
      var radios = scope.querySelectorAll("input[type='radio'][name]");
      var checked = Array.prototype.find.call(radios, function (r) { return r.checked; });
      var isOther = !!(checked && checked.value === "-oth-");
      setHidden(box, !isOther);
    }

    root
      .querySelectorAll("li.answer-item.radio-text-item, .answers-list, .answer-list")
      .forEach(function (scope) {
        var box = getOtherBox(scope);
        if (box) setHidden(box, true);

        scope.querySelectorAll("input[type='radio'][name]").forEach(function (r) {
          function handler() { setTimeout(function () { updateGroup(scope); }, 0); }
          r.addEventListener("change", handler);
          r.addEventListener("click", handler);
        });
        updateGroup(scope);
      });
  }

  /* =========================================================
     7.2 — Checkboxes "Autre" (multiple-opt)
  ========================================================= */
  function initOtherCheckboxes(root) {
    root = root || document;

    var FS_SEL =
      "fieldset.row.multiple-opt.mandatory.question-container, " +
      "fieldset.row.multiple-opt.mandatory.questionnaire-container";
    var OTHER_CB_SEL = FS_SEL + " input.other-checkbox";
    var OTHER_WRAP_SEL = ".text-item.other-text-item";
    var OTHER_INPUT_SEL = "input[type='text'][id$='other']";

    function toggleOther(cb) {
      var li = cb.closest("li");
      if (!li) return;
      var wrap = li.querySelector(OTHER_WRAP_SEL);
      var input = li.querySelector(OTHER_INPUT_SEL);
      if (!wrap || !input) return;
      if (cb.checked) {
        wrap.classList.remove("ls-hidden", "ls-irrelevant", "ls-js-hidden");
        wrap.setAttribute("aria-hidden", "false");
        input.disabled = false;
        input.setAttribute("aria-disabled", "false");
      } else {
        wrap.classList.add("ls-hidden");
        wrap.setAttribute("aria-hidden", "true");
        input.disabled = true;
        input.setAttribute("aria-disabled", "true");
      }
    }

    root.querySelectorAll(OTHER_CB_SEL).forEach(function (cb) {
      if (cb.dataset.otherWired) return;
      cb.dataset.otherWired = "1";
      cb.addEventListener("change", function () { toggleOther(cb); });
      toggleOther(cb);
    });

    root
      .querySelectorAll(FS_SEL + " li[id$='other'] " + OTHER_INPUT_SEL)
      .forEach(function (inp) {
        if (inp.dataset.otherSyncBound) return;
        inp.dataset.otherSyncBound = "1";
        inp.addEventListener("input", function () {
          var li = inp.closest("li");
          var cb = li && li.querySelector("input.other-checkbox");
          if (!cb) return;
          var hasText = inp.value.trim().length > 0;
          if (cb.checked !== hasText) {
            cb.checked = hasText;
            cb.dispatchEvent(new Event("change", { bubbles: true }));
          }
        });
      });
  }

  /* =========================================================
     7.3 — Désactiver complètement "Autre :" sur certaines list-radio mandatory
  ========================================================= */
  function initDisableOtherOnListRadio(root) {
    root = root || document;

    var FS_SEL =
      "fieldset.row.list-radio.mandatory.question-container, " +
      "fieldset.row.list-radio.mandatory.questionnaire-container";

    function disableOther(fs) {
      if (!fs) return;
      var otherRow = fs.querySelector("[id^='div'][id$='other']");
      var otherInput = fs.querySelector("input[id$='othertext'], input[name$='other']");
      if (otherInput) {
        otherInput.required = false;
        otherInput.removeAttribute("required");
        otherInput.disabled = true;
        otherInput.setAttribute("aria-disabled", "true");
        otherInput.classList.remove("em_sq_validation", "em_validation", "ls-em-required");
      }
      if (otherRow) {
        otherRow.style.display = "none";
        otherRow.classList.remove("ls-js-hidden", "ls-irrelevant");
      }
    }

    root.querySelectorAll(FS_SEL).forEach(function (fs) {
      disableOther(fs);
      if (!fs.dataset.otherWired) {
        fs.addEventListener("change", function (e) {
          if (e.target && e.target.type === "radio") disableOther(fs);
        });
        fs.dataset.otherWired = "1";
      }
    });

    setTimeout(function () { root.querySelectorAll(FS_SEL).forEach(disableOther); }, 50);
    setTimeout(function () { root.querySelectorAll(FS_SEL).forEach(disableOther); }, 200);
  }

  /* =========================================================
     7.3a — amélioration affichage option autre avec focus (jQuery)
  ========================================================= */
  function initOtherAutreFocus(root) {
    if (!$) return;
    root = root || document;

    $(root).find("input.other-checkbox").each(function () {
      var $cb = $(this);
      if ($cb.data("lsOtherWired") === 1) return;
      $cb.data("lsOtherWired", 1);

      var $li = $cb.closest("li.question-item, li.answer-item");
      var $wrap = $li.find(".other-text-item").first();
      var $txt = $wrap.find('input[type="text"], textarea').first();
      var $java = $li.find('input[type="hidden"][name^="java"][name$="other"]').first();

      if ($txt.length === 0) return;

      var otherName = $txt.attr("name") || "";

      function showOther() {
        $wrap.removeClass("ls-hidden").attr("aria-hidden", "false");
        $txt.prop("disabled", false);
      }

      function hideOther() {
        $wrap.addClass("ls-hidden").attr("aria-hidden", "true");
        $txt.prop("disabled", true);
      }

      $txt.on("keyup focusout", function () {
        var val = $.trim($txt.val());
        var hasText = val.length > 0;

        if (hasText) {
          $cb.prop("checked", true);
          showOther();
        } else {
          $cb.prop("checked", false);
        }

        if ($java.length) $java.val($txt.val());

        if (typeof LEMflagMandOther === "function") {
          LEMflagMandOther(otherName, $cb.is(":checked"));
        }
        if (typeof checkconditions === "function") {
          checkconditions(this.value, this.name, this.type);
        }
      });

      $cb.on("click", function () {
        if ($cb.is(":checked")) {
          showOther();
          if (typeof LEMflagMandOther === "function") LEMflagMandOther(otherName, true);
          $txt.focus();
          return false;
        } else {
          $txt.val("");
          if ($java.length) $java.val("");
          hideOther();
          if (typeof checkconditions === "function") checkconditions("", otherName, "text");
          if (typeof LEMflagMandOther === "function") LEMflagMandOther(otherName, false);
          return true;
        }
      });

      var hasInitText = $.trim($txt.val()).length > 0;
      if (hasInitText || $cb.is(":checked")) {
        showOther();
        $cb.prop("checked", true);
      } else {
        hideOther();
      }
    });
  }

  /* =========================================================
     7.4 — Forcer affichage des list-with-comment mandatory
  ========================================================= */
  function initForceListWithComment(root) {
    root = root || document;
    var SEL = "fieldset.row.list-with-comment.mandatory";

    root.querySelectorAll(SEL).forEach(function (fs) {
      fs.style.display = "block";
      fs.classList.remove("ls-hidden", "ls-irrelevant");
      fs.removeAttribute("hidden");
      fs.setAttribute("aria-hidden", "false");
      fs.querySelectorAll(".ls-hidden, .ls-irrelevant").forEach(function (el) {
        el.classList.remove("ls-hidden", "ls-irrelevant");
      });
    });
  }

  /* =========================================================
     7.5 — Zone aria-live + message au clic sur Envoyer
  ========================================================= */
  function initAriaLiveSubmitMessage() {
    ensureAriaLiveDiv();

    var btn = document.getElementById("ls-button-submit");
    var liveMessage = document.getElementById("aria-live-message");
    if (!btn || !liveMessage) return;

    if (btn.dataset.lsLiveBound === "1") return;
    btn.dataset.lsLiveBound = "1";

    btn.addEventListener("click", function () {
      if (btn.value === "movesubmit") {
        liveMessage.textContent = "Votre formulaire est en cours de traitement.";
        setTimeout(function () {
          liveMessage.textContent = "";
        }, 3000);
      }
    });
  }

  /* =========================================================
     7.6 — aria-live sur la modal Bootstrap de LS
  ========================================================= */
  function initBootstrapAlertModalAriaLive() {
    var MODAL_ID = "bootstrap-alert-box-modal";

    function toggleAriaLive(isShown) {
      var el = document.getElementById(MODAL_ID);
      if (!el) return;
      if (isShown) {
        el.setAttribute("aria-live", "assertive");
        el.setAttribute("aria-atomic", "true");
      } else {
        el.removeAttribute("aria-live");
        el.removeAttribute("aria-atomic");
      }
    }

    function updateFromClass() {
      var el = document.getElementById(MODAL_ID);
      if (!el) return;
      toggleAriaLive(el.classList.contains("show"));
    }

    var el = document.getElementById(MODAL_ID);
    if (!el) return;

    if (el.dataset.lsModalAriaBound === "1") {
      updateFromClass();
      return;
    }
    el.dataset.lsModalAriaBound = "1";

    updateFromClass();
    el.addEventListener("shown.bs.modal", function () { toggleAriaLive(true); });
    el.addEventListener("hidden.bs.modal", function () { toggleAriaLive(false); });

    var mo = new MutationObserver(updateFromClass);
    mo.observe(el, { attributes: true, attributeFilter: ["class"] });
  }

  /* =========================================================
     8a) multiple-opt-comments : désactiver commentaires lignes non cochées
  ========================================================= */
  function initMultipleOptComments() {
    const UPGRADE_SELECTOR =
      "div.row.multiple-opt-comments.mandatory.question-container," +
      "div.row.multiple-opt-comments.mandatory.questionnaire-container," +
      "div.row.multiple-opt-comments.mandatory.question-containe";

    const FS_SELECTOR =
      "fieldset.row.multiple-opt-comments.mandatory.question-container," +
      "fieldset.row.multiple-opt-comments.mandatory.questionnaire-container," +
      "fieldset.row.multiple-opt-comments.mandatory.question-containe";

    const ROW_SELECTOR = "li.checkbox-text-item, li[id^='javatbd']";
    const COMMENT_SEL = 'input[type="text"][id$="comment"], textarea[id$="comment"]';

    function upgradeOnce(root = document) {
      const nodes = Array.from(root.querySelectorAll(UPGRADE_SELECTOR)).filter(
        (n) => n.tagName !== "FIELDSET" && !n.classList.contains("is-fieldset-upgraded")
      );

      nodes.forEach((div) => {
        const fs = document.createElement("fieldset");
        for (const attr of Array.from(div.attributes)) {
          fs.setAttribute(attr.name, attr.value);
        }
        fs.classList.add("is-fieldset-upgraded");
        fs.setAttribute("role", "group");
        while (div.firstChild) fs.appendChild(div.firstChild);
        div.replaceWith(fs);
      });
    }

    const rowOf = (el) => el && (el.closest(ROW_SELECTOR) || el.closest(".row"));
    const checkboxIn = (row) => (row ? row.querySelector('input[type="checkbox"]') : null);
    const commentsIn = (row) => (row ? Array.from(row.querySelectorAll(COMMENT_SEL)) : []);

    function stripRequired(el) {
      if (!el) return;
      el.required = false;
      el.removeAttribute("required");
      el.removeAttribute("aria-required");
      el.classList.remove("em_sq_validation", "em_validation", "ls-em-required");
    }

    function enableComment(ci, makeRequired) {
      if (!ci) return;
      ci.disabled = false;
      ci.removeAttribute("aria-disabled");
      if (makeRequired) {
        ci.required = true;
        ci.setAttribute("aria-required", "true");
      } else {
        stripRequired(ci);
      }
    }

    function disableComment(ci) {
      if (!ci) return;
      stripRequired(ci);
      ci.disabled = true;
      ci.setAttribute("aria-disabled", "true");
    }

    function syncFieldset(fs) {
      if (!fs) return;

      const rows = Array.from(fs.querySelectorAll(ROW_SELECTOR)).filter((r) => checkboxIn(r));
      if (!rows.length) return;

      rows.forEach((row) => {
        const cb = checkboxIn(row);
        const cms = commentsIn(row);
        if (!cb) return;

        if (cb.checked && !cb.disabled) {
          cms.forEach((ci) => enableComment(ci, true));
        } else {
          cms.forEach(disableComment);
        }
      });
    }

    function onCheckboxChange(e) {
      const t = e.target;
      if (!t || t.type !== "checkbox") return;

      const fs = t.closest(FS_SELECTOR);
      if (fs) {
        syncFieldset(fs);
        if (t.checked && !t.disabled) {
          const row = rowOf(t);
          const cms = commentsIn(row);
          if (cms && cms.length) {
            const ci = cms[0];
            if (ci && !ci.disabled) {
              try { ci.focus(); } catch (err) {}
            }
          }
        }
      }
    }

    document.addEventListener(
      "invalid",
      function (e) {
        const el = e.target;
        if (!el || !el.matches || !el.matches(COMMENT_SEL)) return;

        const row = rowOf(el);
        const cb = checkboxIn(row);
        if (cb && !cb.checked) {
          disableComment(el);
          e.preventDefault();
          e.stopPropagation();
        }
      },
      true
    );

    function init(root = document) {
      upgradeOnce(root);

      root.querySelectorAll(FS_SELECTOR).forEach((fs) => {
        fs.querySelectorAll(COMMENT_SEL).forEach(disableComment);
        syncFieldset(fs);
      });
    }

    function onCommentInput(e) {
      const t = e.target;
      if (!t || !t.matches || !t.matches(COMMENT_SEL)) return;
      const fs = t.closest(FS_SELECTOR);
      if (fs) syncFieldset(fs);
    }

    // Expose init callable from boot()
    initMultipleOptComments._init = init;

    // Global delegations once
    if (!initMultipleOptComments._wired) {
      initMultipleOptComments._wired = true;
      document.addEventListener("change", onCheckboxChange);
      document.addEventListener("input", onCommentInput);

      if (window.jQuery) jQuery(document).on("ajaxComplete", () => init());

      new MutationObserver((muts) => {
        for (const m of muts) {
          for (const n of m.addedNodes || []) {
            if (n && n.nodeType === 1) init(n);
          }
        }
      }).observe(document.documentElement, { childList: true, subtree: true });

      let tries = 0;
      const t = setInterval(() => {
        tries++;
        init();
        if (tries >= 3) clearInterval(t);
      }, 300);
    }
  }

  /* =========================================================
     8) Validation séquentielle + touche Entrée
  ========================================================= */
  function initSequentialValidation() {
    function questionContainerOf(el) {
      return (
        el &&
        el.closest(
          "fieldset[id^='question']," +
            "div[id^='question']," +
            "fieldset.question-container," +
            "div.question-container," +
            ".row.text-short," +
            ".row.text-long," +
            "fieldset.list-radio," +
            "fieldset.radio-list," +
            "fieldset.multiple-opt," +
            "fieldset.list-dropdown," +
            ".list-dropdown"
        )
      );
    }

    function questionTitle(q) {
      if (!q) return "cette question";
      var lg = q.querySelector(":scope > legend");
      if (lg && lg.textContent.trim()) return lg.textContent.trim();
      var lb = q.querySelector(":scope > label, label.ls-label-question");
      if (lb && lb.textContent.trim()) return lb.textContent.replace("*", "").trim();
      return "cette question";
    }

    function clearTip(q) {
      if (!q) return;
      q.querySelectorAll(":scope > .ls-tip-right").forEach(function (n) {
        n.parentNode.removeChild(n);
      });
      q.classList.remove("ls-tip-error", "ls-tip-anchor");
    }

    function clearAllTips(root) {
      root = root || document;
      root.querySelectorAll(".ls-tip-right").forEach(function (n) {
        n.parentNode.removeChild(n);
      });
      root.querySelectorAll(".ls-tip-anchor.ls-tip-error").forEach(function (q) {
        q.classList.remove("ls-tip-error", "ls-tip-anchor");
      });
    }

    function showRightTip(targetOrQ, msg) {
      var q = questionContainerOf(targetOrQ) || targetOrQ;
      if (!q) return;
      clearTip(q);
      q.classList.add("ls-tip-anchor", "ls-tip-error");

      var tip = document.createElement("div");
      tip.className = "ls-tip-right";
      tip.setAttribute("role", "alert");
      tip.setAttribute("aria-live", "assertive");
      tip.textContent = msg;

      var legend = q.querySelector(":scope > legend");
      if (legend) legend.insertAdjacentElement("afterend", tip);
      else q.insertAdjacentElement("afterbegin", tip);
    }

    function questionNodes(root) {
      root = root || document;
      var sel =
        "fieldset[id^='question']," +
        "div[id^='question']," +
        "fieldset.question-container," +
        "div.question-container," +
        ".row.text-short," +
        ".row.text-long," +
        "fieldset.list-radio," +
        "fieldset.radio-list," +
        "fieldset.multiple-opt," +
        "fieldset.list-dropdown," +
        ".list-dropdown";
      var seen = new WeakSet();
      return Array.prototype.filter.call(root.querySelectorAll(sel), function (q) {
        if (seen.has(q)) return false;
        seen.add(q);
        if (!isVisible(q)) return false;
        if (q.classList.contains("mandatory")) return true;
        if (q.querySelector("[required]")) return true;
        return false;
      });
    }

    function firstErrorInQuestion(q) {
      if (!isVisible(q)) return null;
      var title = questionTitle(q);

      // array-flexible-row : 1 réponse par ligne obligatoire
      if (q.classList.contains("array-flexible-row")) {
        var table = q.querySelector(".ls-table-wrapper table");
        if (table) {
          var rows = table.querySelectorAll("tbody tr");
          for (var r = 0; r < rows.length; r++) {
            var row = rows[r];
            var radios = row.querySelectorAll('input[type="radio"][name]');
            if (!radios.length) continue;

            var anyChecked = Array.prototype.some.call(radios, function (ra) {
              return ra.checked && !ra.disabled;
            });

            if (!anyChecked) {
              var th = row.querySelector("th.answertext, th");
              var labelPart = "";
              if (th && th.textContent) labelPart = th.textContent.replace(/\s+/g, " ").trim();
              if (!labelPart) labelPart = title;

              return { el: radios[0], msg: "Veuillez sélectionner une réponse pour la sous-question « " + labelPart + " »." };
            }
          }
        }
      }

      // multiple-opt mandatory
      if (q.matches("fieldset.multiple-opt.mandatory, .multiple-opt.mandatory")) {
        var boxes = Array.prototype.filter.call(q.querySelectorAll('input[type="checkbox"]'), function (b) {
          return isVisible(b) && !b.disabled;
        });
        if (boxes.length && !boxes.some(function (b) { return b.checked; })) {
          return { el: boxes[0], msg: "Veuillez cocher au moins une option : " + title };
        }
      }

      // multiple-opt-comments mandatory
      if (q.matches("fieldset.multiple-opt-comments.mandatory, .multiple-opt-comments.mandatory")) {
        var boxes2 = Array.prototype.filter.call(q.querySelectorAll('input[type="checkbox"]'), function (b) {
          return isVisible(b) && !b.disabled;
        });
        if (boxes2.length && !boxes2.some(function (b) { return b.checked; })) {
          return { el: boxes2[0], msg: "Veuillez cocher au moins une option : " + title };
        }
      }

      // radio groups
      var radiosAll = Array.prototype.filter.call(q.querySelectorAll('input[type="radio"][name]'), function (r) {
        return isVisible(r) && !r.disabled;
      });
      if (radiosAll.length) {
        var groups = {};
        radiosAll.forEach(function (r) {
          if (!groups[r.name]) groups[r.name] = [];
          groups[r.name].push(r);
        });

        var names = Object.keys(groups);
        for (var i = 0; i < names.length; i++) {
          var arr = groups[names[i]];
          var any = arr.some(function (r) { return r.checked; });

          var isMandatoryGroup = q.classList.contains("mandatory") || !!q.closest(".mandatory");

          if (isMandatoryGroup && !any) {
            return { el: arr[0], msg: "Veuillez sélectionner une option : " + title };
          }
        }
      }

      // date triplets
      var day = q.querySelector("select.day");
      var month = q.querySelector("select.month");
      var year = q.querySelector("select.year");
      var isDateQuestion = day || month || year;
      var isMandatoryDate = isDateQuestion && (q.classList.contains("mandatory") || !!q.closest(".mandatory"));

      if (isMandatoryDate) {
        var firstEmpty = null;
        if (day && isVisible(day) && !day.disabled && !day.value) firstEmpty = day;
        else if (month && isVisible(month) && !month.disabled && !month.value) firstEmpty = month;
        else if (year && isVisible(year) && !year.disabled && !year.value) firstEmpty = year;

        if (firstEmpty) {
          var partLabel = "la date";
          if (firstEmpty === day) partLabel = "le jour";
          if (firstEmpty === month) partLabel = "le mois";
          if (firstEmpty === year) partLabel = "l’année";
          return { el: firstEmpty, msg: "Veuillez renseigner " + partLabel + " pour : " + title };
        }
      }

      // required fields
      var fields = q.querySelectorAll(
        "input[required]:not([type='checkbox']):not([type='radio'])," +
          "select[required]," +
          "textarea[required]"
      );
      for (var j = 0; j < fields.length; j++) {
        var el = fields[j];
        if (!isVisible(el) || el.disabled) continue;
        var tag = el.tagName;
        var val = tag === "SELECT" ? el.value : (el.value || "").trim();

        if (!val || (el.checkValidity && !el.checkValidity())) {
          var msg;

          var isCommentField =
            /comment$/.test(el.id || "") && (el.matches('input[type="text"]') || el.matches("textarea"));

          if (isCommentField) {
            var lineLabel = null;
            var labId = el.getAttribute("aria-labelledby");
            if (labId) {
              var labNode = document.getElementById(labId);
              if (labNode && labNode.textContent.trim()) lineLabel = labNode.textContent.replace(/\s+/g, " ").trim();
            }
            if (!lineLabel) {
              var liNode = el.closest("li");
              if (liNode) {
                var lab2 = liNode.querySelector("label");
                if (lab2 && lab2.textContent.trim()) lineLabel = lab2.textContent.replace(/\s+/g, " ").trim();
              }
            }
            if (lineLabel) msg = "Veuillez renseigner le commentaire pour la ligne « " + lineLabel + " ».";
          }

          if (!msg) {
            var name = title;
            var id = el.id;
            if (id) {
              var lb = q.querySelector('label[for="' + id.replace(/"/g, "") + '"]');
              if (lb && lb.textContent.trim()) name = lb.textContent.replace("*", "").trim();
            }
            msg = "Veuillez compléter ce champ : " + name;

            if (el.validity) {
              if (el.validity.typeMismatch) msg = "Le format de " + name + " est invalide";
              else if (el.validity.tooShort) msg = name + " est trop court (minimum " + el.minLength + " caractères)";
              else if (el.validity.tooLong) msg = name + " est trop long (maximum " + el.maxLength + " caractères)";
              else if (el.validity.patternMismatch) msg = name + " ne correspond pas au format attendu";
            }
          }

          return { el: el, msg: msg };
        }
      }

      return null;
    }

    function currentGroupRoot() {
      var groups = Array.prototype.slice.call(document.querySelectorAll(".group-outer-container[id^='group-']"));
      var vis = groups.find(function (g) { return isVisible(g); });
      if (vis) {
        var inner = vis.querySelector("fieldset.group-container, .group-container, .ls-group-container");
        return inner || vis;
      }
      return (
        document.querySelector("#group-container") ||
        document.querySelector(".ls-group-container") ||
        document.querySelector("fieldset.group-container") ||
        document
      );
    }

    function validateOneQuestionIn(form) {
      clearAllTips(form);
      var root = currentGroupRoot();
      var qs = questionNodes(root);
      for (var i = 0; i < qs.length; i++) {
        var q = qs[i];
        var err = firstErrorInQuestion(q);
        if (err) {
          showRightTip(err.el || q, err.msg);
          try { (err.el || q).focus({ preventScroll: true }); } catch (e) {}
          try { (err.el || q).scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e2) {}
          return false;
        }
      }
      return true;
    }

    function setupLiveTipCleanup() {
      if (window.__LS_LIVE_TIP_CLEANUP__) return;
      window.__LS_LIVE_TIP_CLEANUP__ = true;

      function handleUserEdit(e) {
        var t = e.target;
        if (!t || !t.matches("input, select, textarea")) return;
        var q = questionContainerOf(t);
        if (q) clearTip(q);
      }

      document.addEventListener("input", handleUserEdit, true);
      document.addEventListener("change", handleUserEdit, true);
    }

    function wireNextButtons() {
      // novalidate (bulle native)
      document.querySelectorAll("form").forEach(function (f) {
        f.setAttribute("novalidate", "novalidate");
      });
      document.addEventListener(
        "invalid",
        function (e) { e.preventDefault(); },
        true
      );

      // Click Next / Submit
      document.addEventListener(
        "click",
        function (e) {
          var btn = e.target && e.target.closest("button, input[type='submit']");
          if (!btn) return;

          var isNav = btn.matches(
            'button[name="move"][value="movenext"],' +
              'input[type="submit"][name="move"][value="movenext"],' +
              'button[name="move"][value="movesubmit"],' +
              'input[type="submit"][name="move"][value="movesubmit"],' +
              "#ls-button-submit"
          );
          if (!isNav) return;

          var form = btn.form || document.querySelector("form");
          if (!form) return;

          if (!validateOneQuestionIn(form)) {
            e.preventDefault();
            e.stopPropagation();
          }
        },
        true
      );

      // Enter key
      document.addEventListener(
        "keydown",
        function (e) {
          if (e.key !== "Enter" || e.defaultPrevented) return;

          var t = e.target;
          if (!t) return;

          if (
            t.closest("textarea, [contenteditable], .note-editable") ||
            t.isContentEditable ||
            e.ctrlKey ||
            e.altKey ||
            e.metaKey
          ) {
            return;
          }

          if (t.closest("button, input[type='submit'], [role='button']")) return;

          var form = t.closest("form");
          if (!form) return;

          var btn =
            form.querySelector("#ls-button-submit") ||
            form.querySelector('button[name="move"][value="movenext"]') ||
            form.querySelector('input[type="submit"][name="move"][value="movenext"]') ||
            form.querySelector('button[name="move"][value="movesubmit"]') ||
            form.querySelector('input[type="submit"][name="move"][value="movesubmit"]');

          if (!btn) return;

          e.preventDefault();

          if (!validateOneQuestionIn(form)) return;

          btn.click();
        },
        true
      );
    }

    function boot() {
      setupLiveTipCleanup();
      wireNextButtons();
    }

    // Anti multi-boot (pjax:success rappelle)
    if (!window.__LS_SEQ_VALID_BOOT__) {
      window.__LS_SEQ_VALID_BOOT__ = true;
      if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
      else boot();
      document.addEventListener("pjax:success", boot);
    }
  }

  /* =========================================================
     Focus styles sur choix (radio/checkbox/array)
  ========================================================= */
  function initChoiceFocusStyles(root) {
    root = root || document;

    root.querySelectorAll(
      ".radio-list input[type='radio']," +
        ".checkbox-list input[type='checkbox']," +
        ".array-flexible-row .ls-table-wrapper input[type='radio']," +
        ".array-flexible-row .ls-table-wrapper input[type='checkbox']," +
        ".array-flexible-row .ls-table-wrapper select," +
        ".array-flexible-row .ls-table-wrapper textarea"
    ).forEach(function (input) {
      if (input.dataset.lsFocusWired === "1") return;
      input.dataset.lsFocusWired = "1";

      input.addEventListener("focus", function () {
        var question = input.closest(".question-container, fieldset.question-container") || document;
        question.querySelectorAll(".ls-radio-focus").forEach(function (el) {
          el.classList.remove("ls-radio-focus");
        });

        var container =
          input.closest("li.answer-item") ||
          input.closest("li") ||
          input.closest("td.answer-item") ||
          input.closest("tr.answers-list");

        if (container) container.classList.add("ls-radio-focus");
      });

      input.addEventListener("blur", function () {
        var container =
          input.closest("li.answer-item") ||
          input.closest("li") ||
          input.closest("td.answer-item") ||
          input.closest("tr.answers-list");

        if (container) container.classList.remove("ls-radio-focus");
      });
    });
  }

  /* =========================================================
     BOOT GLOBAL
  ========================================================= */
  function boot(root) {
    root = root || document;

    // Si tu n'as PAS mis le div aria-live en twig, on le crée.
    ensureAriaLiveDiv();

    // Init "one time" global handlers
    wireMaxLenDelegation();
    wireRelevanceHandlers();

    // Init / update sur root (chargement + PJAX)
    initDateTriplets(root);
    initDatePlaceholders();
    initDivToFieldset(root);

    removeAlertRoleOnQuestionHelp(root);

    initOtherRadios(root);
    initOtherCheckboxes(root);
    initDisableOtherOnListRadio(root);
    initOtherAutreFocus(root);
    initForceListWithComment(root);

    hideNativePickers(root);

    initSiOuiQuestions(root);

    initAriaLiveSubmitMessage();
    initBootstrapAlertModalAriaLive();

    initChoiceFocusStyles(root);

    // Blocs qui installent leurs observers / comportements globaux
    if (!window.__LS_REQUIRED_CLEANUP_OBS__) {
      window.__LS_REQUIRED_CLEANUP_OBS__ = true;
      initRequiredCleanupObservers();
    }
    if (!window.__LS_REQUIRED_OBS__) {
      window.__LS_REQUIRED_OBS__ = true;
      initRequiredObserver();
    }
    if (!window.__LS_TEXT_REQUIRED_OBS__) {
      window.__LS_TEXT_REQUIRED_OBS__ = true;
      initTextLongShortRequiredObserver();
    }
    if (!window.__LS_LISTRADIO_REQUIRED_OBS__) {
      window.__LS_LISTRADIO_REQUIRED_OBS__ = true;
      initListRadioRequiredObserver();
    }
    if (!window.__LS_ROW_REQUIRED_OBS__) {
      window.__LS_ROW_REQUIRED_OBS__ = true;
      initRowRequiredObservers();
    }
    if (!window.__LS_UNHIDE_RELEVANT_OBS__) {
      window.__LS_UNHIDE_RELEVANT_OBS__ = true;
      initUnhideRelevantWatcher();
    }

    // Auto types : boot unique
    initAutoTypes();

    // multiple-opt-comments manager
    initMultipleOptComments();
    if (initMultipleOptComments._init) initMultipleOptComments._init(root);

    // Sequential validation
    initSequentialValidation();
  }

  // Initial
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { boot(document); });
  } else {
    boot(document);
  }

  // PJAX
  document.addEventListener("pjax:success", function (e) {
    boot((e && e.target) ? e.target : document);
  });

  // Filet (certains thèmes/chargements tardifs)
  setTimeout(function () { boot(document); }, 250);
  setTimeout(function () { boot(document); }, 1200);

})(window, document, window.jQuery);
